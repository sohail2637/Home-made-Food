module.exports={
    secret: 'maano'
    
}